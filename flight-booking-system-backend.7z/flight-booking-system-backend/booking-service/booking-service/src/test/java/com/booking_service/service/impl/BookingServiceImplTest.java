package com.booking_service.service.impl;

import com.booking_service.dto.BookingMailRequest;
import com.booking_service.dto.CreateBookingRequest;
import com.booking_service.dto.PaymentStatusResponse;
import com.booking_service.external.FlightSearchClient;
import com.booking_service.external.MailServiceClient;
import com.booking_service.external.PaymentClient;
import com.booking_service.model.*;
import com.booking_service.repositories.BookingRepository;
import com.booking_service.service.BookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceImplTest {

    @InjectMocks
    private BookingServiceImpl bookingService;

    @Mock
    private BookingRepository bookingRepository;
    @Mock
    private PaymentClient paymentClient;
    @Mock
    private FlightSearchClient flightSearchClient;
    @Mock
    private MailServiceClient mailServiceClient;

    private CreateBookingRequest request;
    private Booking booking;

    @BeforeEach
    void setup() {
        request = new CreateBookingRequest();
        request.setName("John");
        request.setEmail("john@example.com");
        request.setContact("9876543210");
        request.setFlightNumber("AI101");
        request.setSeatType(SeatType.ECONOMY_CLASS);
        request.setNoOfSeats(2);
        request.setCurrency("INR");

        booking = Booking.builder()
                .id(1L)
                .name("John")
                .email("john@example.com")
                .contact("9876543210")
                .flightNumber("AI101")
                .seatType(SeatType.ECONOMY_CLASS)
                .noOfSeats(2)
                .username("johndoe")
                .currency("INR")
                .bookingStatus(BookingStatus.PENDING)
                .paymentStatus(PaymentStatus.PENDING)
                .build();
    }

    @Test
    void createBooking_shouldCreateBookingSuccessfully() {
        when(flightSearchClient.existByFlightNumber("AI101")).thenReturn(true);
        when(bookingRepository.save(any())).thenReturn(booking);
        when(flightSearchClient.getFare(any(), any())).thenReturn(5000.0);
        when(paymentClient.createOrder(anyDouble(), anyString(), anyString()))
                .thenReturn(Map.of("payment_url", "http://payment.com", "id", "order123"));

        Booking created = bookingService.createBooking(request, "johndoe");

        assertThat(created.getPaymentUrl()).isEqualTo("http://payment.com");
        verify(bookingRepository, times(2)).save(any());
    }

    @Test
    void createBooking_shouldThrowIfFlightNotExist() {
        when(flightSearchClient.existByFlightNumber("AI101")).thenReturn(false);

        assertThatThrownBy(() -> bookingService.createBooking(request, "johndoe"))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("Flight not found");
    }

    @Test
    void confirmBooking_shouldThrowIfBookingNotFound() {
        when(bookingRepository.findByBookingId("AI101-EC-0001")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> bookingService.confirmBooking("AI101-EC-0001", "johndoe"))
                .isInstanceOf(ResponseStatusException.class);
    }

    @Test
    void confirmBooking_shouldThrowIfPaymentPending() {
        booking.setBookingId("AI101-EC-0001");
        when(bookingRepository.findByBookingId("AI101-EC-0001")).thenReturn(Optional.of(booking));
        when(paymentClient.verifyPayment(any())).thenReturn(new PaymentStatusResponse("order123", "pay123", "pending"));

        assertThatThrownBy(() -> bookingService.confirmBooking("AI101-EC-0001", "johndoe"))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("Payment not completed");
    }

    @Test
    void cancelBooking_shouldUpdateStatusAndSendMail() {
        booking.setBookingId("AI101-EC-0001");
        when(bookingRepository.findByBookingId("AI101-EC-0001")).thenReturn(Optional.of(booking));

        String result = bookingService.cancelBooking("AI101-EC-0001", "johndoe");

        verify(paymentClient).refundPayment(any());
        verify(mailServiceClient).sendCancellationMail("john@example.com", "AI101-EC-0001");
        assertThat(result).contains("cancelled successfully");
    }

    @Test
    void updateStatusToCheckedIn_shouldUpdateBookingStatus() {
        booking.setBookingId("AI101-EC-0001");
        when(bookingRepository.findByBookingId("AI101-EC-0001")).thenReturn(Optional.of(booking));

        bookingService.updateStatusToCheckedIn("AI101-EC-0001");

        verify(bookingRepository).save(argThat(b -> b.getBookingStatus() == BookingStatus.CHECKED_IN));
    }
}