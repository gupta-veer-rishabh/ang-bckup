package com.booking_service.controller;

import com.booking_service.model.Booking;
import com.booking_service.model.BookingStatus;
import com.booking_service.model.SeatType;
import com.booking_service.service.BookingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.ArgumentMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BookingController.class)
class BookingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookingService bookingService;

    @Autowired
    private ObjectMapper objectMapper;

    private Booking createMockBooking() {
        return Booking.builder()
                .bookingId("AI101-EC-0001")
                .name("Alice")
                .email("alice@example.com")
                .contact("9999999999")
                .flightNumber("AI101")
                .seatType(SeatType.ECONOMY_CLASS)
                .noOfSeats(2)
                .bookingStatus(BookingStatus.CONFIRMED)
                .build();
    }

    @Test
    void createBooking_shouldReturn200() throws Exception {
        Booking booking = createMockBooking();
        Mockito.when(bookingService.createBooking(any(), anyString())).thenReturn(booking);

        mockMvc.perform(post("/api/bookings/create-booking")
                        .header("X-Username", "alice")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(booking)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.bookingId").value("AI101-EC-0001"));
    }

    @Test
    void confirmBooking_shouldReturnBooking() throws Exception {
        Booking booking = createMockBooking();
        Mockito.when(bookingService.confirmBooking(anyString(), anyString())).thenReturn(booking);

        mockMvc.perform(post("/api/bookings/AI101-EC-0001/confirm")
                        .header("X-Username", "alice"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.bookingId").value("AI101-EC-0001"));
    }

    @Test
    void cancelBooking_shouldReturnSuccessMessage() throws Exception {
        Mockito.when(bookingService.cancelBooking(anyString(), anyString())).thenReturn("Cancelled!");

        mockMvc.perform(put("/api/bookings/AI101-EC-0001/cancel")
                        .header("X-Username", "alice"))
                .andExpect(status().isOk())
                .andExpect(content().string("Cancelled!"));
    }

    @Test
    void getAllBookings_shouldReturnList() throws Exception {
        Mockito.when(bookingService.getAllBookings()).thenReturn(List.of(createMockBooking()));

        mockMvc.perform(get("/api/bookings/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].bookingId").value("AI101-EC-0001"));
    }

    @Test
    void getUserBookings_shouldReturnEmptyList() throws Exception {
        Mockito.when(bookingService.getBookingsByUsername(anyString())).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/bookings/user/all")
                        .header("X-Username", "bob"))
                .andExpect(status().isOk())
                .andExpect(status().reason(containsString("No booking found")));
    }

    @Test
    void updateBookingStatus_shouldReturnSuccessMessage() throws Exception {
        mockMvc.perform(put("/api/bookings/status/AI101-EC-0001"))
                .andExpect(status().isOk())
                .andExpect(content().string("Booking status updated to CHECKED_IN"));
    }
}