package com.booking_service.model;

public enum BookingStatus {
    PENDING, CONFIRMED, CANCELLED, CHECKED_IN
}
