package com.booking_service.model;

public enum PaymentStatus {
    PAID, PENDING, REFUNDED
}
