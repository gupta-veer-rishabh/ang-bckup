package com.checkin_service.model;

public enum SeatType {
    ECONOMY_CLASS,
    BUSINESS_CLASS,
    FIRST_CLASS,
    PREMIUM_CLASS
}
