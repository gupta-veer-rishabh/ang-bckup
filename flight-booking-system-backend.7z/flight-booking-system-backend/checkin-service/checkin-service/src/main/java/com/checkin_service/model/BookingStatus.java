package com.checkin_service.model;

public enum BookingStatus {
    PENDING, CONFIRMED, CANCELLED, CHECKEDIN
}
