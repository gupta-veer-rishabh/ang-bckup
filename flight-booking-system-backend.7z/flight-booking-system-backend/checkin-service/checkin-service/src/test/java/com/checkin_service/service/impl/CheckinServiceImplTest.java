package com.checkin_service.service.impl;

import com.checkin_service.dto.CheckinMailRequestDTO;
import com.checkin_service.dto.CheckinResponseDTO;
import com.checkin_service.external.BookingServiceClient;
import com.checkin_service.external.MailServiceClient;
import com.checkin_service.model.Booking;
import com.checkin_service.model.Checkin;
import com.checkin_service.model.SeatType;
import com.checkin_service.repositories.CheckinRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CheckinServiceImplTest {

    @Mock private BookingServiceClient bookingClient;
    @Mock private MailServiceClient mailClient;
    @Mock private CheckinRepository checkinRepo;

    @InjectMocks private CheckinServiceImpl service;

    private String futureBookingId;

    @BeforeEach
    void setUp() {
        // bookingId timestamp far in the future so no SERVICE_UNAVAILABLE
        futureBookingId = "ABC99999999X9999ZZZ";
    }

    @Test
    void checkinPassenger_Success() {
        Booking booking = Booking.builder()
                .bookingId(futureBookingId)
                .email("jane@doe.com")
                .username("jane")
                .seatType(SeatType.ECONOMY_CLASS)
                .noOfSeats(2)
                .build();

        when(bookingClient.getBookingByIdForUser(futureBookingId, "jane"))
                .thenReturn(booking);
        when(checkinRepo.findMaxLastSeatBySeatType(SeatType.ECONOMY_CLASS))
                .thenReturn(null);

        ArgumentCaptor<Checkin> captor = ArgumentCaptor.forClass(Checkin.class);
        Checkin saved = Checkin.builder()
                .checkinId(17L)
                .bookingId(booking.getBookingId())
                .seatType(booking.getSeatType())
                .noOfSeats(2)
                .assignedSeats(List.of("EC-002", "EC-003"))
                .build();
        when(checkinRepo.save(captor.capture())).thenReturn(saved);
        when(mailClient.sendCheckinMail(any(CheckinMailRequestDTO.class))).thenReturn("OK");
        when(bookingClient.updateBookingStatusToCheckedIn(futureBookingId)).thenReturn("UPDATED");

        CheckinResponseDTO dto = service.checkinPassenger(futureBookingId, "jane");

        // verify saved entity details
        Checkin toSave = captor.getValue();
        assertEquals(List.of("EC-002", "EC-003"), toSave.getAssignedSeats());
        assertEquals(2, toSave.getNoOfSeats());

        // verify returned DTO
        assertEquals(17L, dto.getCheckinId());
        assertEquals(futureBookingId, dto.getBookingId());
        assertEquals(2, dto.getNoOfSeats());
    }

    @Test
    void checkinPassenger_PastDeparture_ThrowsServiceUnavailable() {
        // bookingId timestamp in the past
        String oldId = "ABC20000101X0000ZZZ";
        Booking booking = Booking.builder()
                .bookingId(oldId)
                .username("jane")
                .seatType(SeatType.ECONOMY_CLASS)
                .noOfSeats(1)
                .build();

        when(bookingClient.getBookingByIdForUser(oldId, "jane"))
                .thenReturn(booking);

        ResponseStatusException ex = assertThrows(
                ResponseStatusException.class,
                () -> service.checkinPassenger(oldId, "jane")
        );

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, ex.getStatusCode());
        assertEquals(503, ex.getStatusCode().value());
        assertTrue(ex.getReason().contains("departed"));
    }

    @Test
    void getAllCheckins_NonEmpty() {
        Checkin a = Checkin.builder()
                .checkinId(1L).bookingId("B1")
                .seatType(SeatType.BUSINESS_CLASS)
                .noOfSeats(1)
                .assignedSeats(List.of("BU-002"))
                .build();
        Checkin b = Checkin.builder()
                .checkinId(2L).bookingId("B2")
                .seatType(SeatType.FIRST_CLASS)
                .noOfSeats(2)
                .assignedSeats(List.of("FI-002", "FI-003"))
                .build();

        when(checkinRepo.findAll()).thenReturn(List.of(a, b));

        List<CheckinResponseDTO> dtos = service.getAllCheckins();
        assertEquals(2, dtos.size());
        assertEquals("B1", dtos.get(0).getBookingId());
        assertEquals(2, dtos.get(1).getNoOfSeats());
    }

    @Test
    void getAllCheckins_Empty_ThrowsNotFound() {
        when(checkinRepo.findAll()).thenReturn(new ArrayList<>());

        ResponseStatusException ex = assertThrows(
                ResponseStatusException.class,
                () -> service.getAllCheckins()
        );

        assertEquals(HttpStatus.NOT_FOUND, ex.getStatusCode());
        assertEquals(404, ex.getStatusCode().value());
        assertTrue(ex.getReason().contains("No checkins available."));
    }
}