package com.checkin_service.controller;

import com.checkin_service.controlller.CheckinController;
import com.checkin_service.dto.CheckinResponseDTO;
import com.checkin_service.service.CheckinService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CheckinController.class)
class CheckinControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private CheckinService checkinService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void checkinPassenger_HappyPath() throws Exception {
        CheckinResponseDTO dto = CheckinResponseDTO.builder()
                .checkinId(1L)
                .bookingId("ABC123")
                .seatType(null)     // you can fill in an enum if you like
                .noOfSeats(2)
                .assignedSeats(List.of("EC-002","EC-003"))
                .build();

        when(checkinService.checkinPassenger("ABC123", "john"))
                .thenReturn(dto);

        mockMvc.perform(post("/api/checkin/ABC123")
                        .header("X-Username", "john"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.checkinId").value(1))
                .andExpect(jsonPath("$.bookingId").value("ABC123"))
                .andExpect(jsonPath("$.noOfSeats").value(2))
                .andExpect(jsonPath("$.assignedSeats[0]").value("EC-002"));
    }

    @Test
    void checkinPassenger_ServiceThrowsException_IsPropagated() throws Exception {
        doThrow(new ResponseStatusException(
                org.springframework.http.HttpStatus.SERVICE_UNAVAILABLE,
                "Flight has been departed."))
                .when(checkinService).checkinPassenger(anyString(), anyString());

        mockMvc.perform(post("/api/checkin/OLDID")
                        .header("X-Username", "john"))
                .andExpect(status().isServiceUnavailable())
                .andExpect(status().reason("Flight has been departed."));
    }

    @Test
    void getAllCheckins_HappyPath() throws Exception {
        CheckinResponseDTO a = new CheckinResponseDTO(1L, "B1", null, 1, List.of("EC-002"));
        CheckinResponseDTO b = new CheckinResponseDTO(2L, "B2", null, 2, List.of("EC-002","EC-003"));

        when(checkinService.getAllCheckins()).thenReturn(List.of(a, b));

        mockMvc.perform(get("/api/checkin/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[1].checkinId").value(2))
                .andExpect(jsonPath("$[1].bookingId").value("B2"));
    }

    @Test
    void getAllCheckins_Empty_ThrowsNotFound() throws Exception {
        when(checkinService.getAllCheckins())
                .thenThrow(new ResponseStatusException(
                        org.springframework.http.HttpStatus.NOT_FOUND,
                        "No checkins available."));

        mockMvc.perform(get("/api/checkin/all"))
                .andExpect(status().isNotFound())
                .andExpect(status().reason("No checkins available."));
    }
}