package com.mail_service.dto;

import lombok.*;

import java.util.List;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CheckinMailRequestDTO {
    private String bookingId;
    private Long checkinId;
    private String email;
    private List<String> assignedSeats;
}
