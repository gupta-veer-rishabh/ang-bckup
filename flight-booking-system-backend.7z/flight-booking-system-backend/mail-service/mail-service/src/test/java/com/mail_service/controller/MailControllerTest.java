// src/test/java/com/mail_service/controller/MailControllerTest.java
package com.mail_service.controller;

import com.mail_service.dto.BookingMailRequest;
import com.mail_service.dto.CheckinMailRequestDTO;
import com.mail_service.service.MailService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailAuthenticationException;

import java.util.List;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MailControllerTest {

    @Mock
    private MailService mailService;

    @InjectMocks
    private MailController controller;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void generateAndSendOtp_success() {
        ResponseEntity<String> resp = controller.generateAndSendOtp("user@example.com");
        assertThat(resp.getStatusCodeValue()).isEqualTo(200);
        assertThat(resp.getBody()).isEqualTo("OTP sent successfully to user@example.com");
        verify(mailService).generateAndSendOtp("user@example.com");
    }

    @Test
    public void generateAndSendOtp_whenMailAuthException_propagates() {
        doThrow(new MailAuthenticationException("Bad creds"))
                .when(mailService).generateAndSendOtp(anyString());

        assertThatThrownBy(() -> controller.generateAndSendOtp("x@y.com"))
                .isInstanceOf(MailAuthenticationException.class)
                .hasMessageContaining("Bad creds");
    }

    @Test
    public void verifyOtp_trueAndFalse() {
        when(mailService.verifyOtp("a@b.com","1234")).thenReturn(true);
        when(mailService.verifyOtp("a@b.com","0000")).thenReturn(false);

        assertThat(controller.verifyOtp("a@b.com","1234")).isTrue();
        assertThat(controller.verifyOtp("a@b.com","0000")).isFalse();
    }

    @Test
    public void sendBookingMail_success() {
        BookingMailRequest req = BookingMailRequest.builder()
                .bookingId("B1").name("Jane").email("jane@x.com")
                .contact("1234").flightNumber("F1")
                .bookingStatus("CONFIRMED").seatType("ECONOMY")
                .noOfSeats(2).paymentStatus("PAID").paymentId("P1")
                .build();

        ResponseEntity<String> resp = controller.sendBookingMail(req);

        assertThat(resp.getStatusCodeValue()).isEqualTo(200);
        assertThat(resp.getBody()).isEqualTo("Booking email sent to jane@x.com");
        verify(mailService).sendBookingEmail(req);
    }

    @Test
    public void sendCancellationMail_success() {
        ResponseEntity<String> resp = controller.sendCancellationMail("u@z.com","B2");

        assertThat(resp.getStatusCodeValue()).isEqualTo(200);
        assertThat(resp.getBody()).isEqualTo("Cancellation email sent to u@z.com");
        verify(mailService).sendBookingCancellationEmail("u@z.com","B2");
    }

    @Test
    public void sendCheckinMail_success() {
        CheckinMailRequestDTO dto = new CheckinMailRequestDTO(
                "B3", 101L, "c@c.com", List.of("1A","1B")
        );
        when(mailService.sendCheckinMail(dto)).thenReturn("Done");

        ResponseEntity<String> resp = controller.sendCheckinMail(dto);

        assertThat(resp.getStatusCodeValue()).isEqualTo(200);
        assertThat(resp.getBody()).isEqualTo("Done");
        verify(mailService).sendCheckinMail(dto);
    }
}