// src/test/java/com/mail_service/service/MailServiceTest.java
package com.mail_service.service;

import com.mail_service.dto.BookingMailRequest;
import com.mail_service.dto.CheckinMailRequestDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.mail.MailAuthenticationException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MailServiceTest {

    @Mock
    private JavaMailSender mailSender;

    @InjectMocks
    private MailService service;

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void generateAndSendOtp_sendsMailAndStoresOtp() throws Exception {
        ArgumentCaptor<SimpleMailMessage> cap = ArgumentCaptor.forClass(SimpleMailMessage.class);

        service.generateAndSendOtp("test@x.com");

        verify(mailSender).send(cap.capture());
        SimpleMailMessage msg = cap.getValue();
        assertThat(msg.getTo()).containsExactly("test@x.com");
        assertThat(msg.getSubject()).isEqualTo("Your OTP Code");
        assertThat(msg.getText()).startsWith("Your OTP from Flight Booking System is: ");

        // reflectively inspect otpStorage
        Field f = MailService.class.getDeclaredField("otpStorage");
        f.setAccessible(true);
        Map<String,String> otpMap = (Map<String,String>) f.get(service);
        assertThat(otpMap).containsKey("test@x.com");
    }

    @Test
    public void generateAndSendOtp_whenMailAuthException_propagates() {
        doThrow(new MailAuthenticationException("Bad creds"))
                .when(mailSender).send(any(SimpleMailMessage.class));

        assertThatThrownBy(() -> service.generateAndSendOtp("a@b.com"))
                .isInstanceOf(MailAuthenticationException.class)
                .hasMessageContaining("Bad creds");
    }

    @Test
    public void verifyOtp_successAndRemoval() throws Exception {
        // prime storage via reflection
        Field f = MailService.class.getDeclaredField("otpStorage");
        f.setAccessible(true);
        Map<String,String> otpMap = (Map<String,String>) f.get(service);
        otpMap.put("u@v.com", "999999");

        boolean ok = service.verifyOtp("u@v.com", "999999");
        assertThat(ok).isTrue();
        assertThat(otpMap).doesNotContainKey("u@v.com");
    }

    @Test
    public void verifyOtp_failure_doesNotRemove() throws Exception {
        Field f = MailService.class.getDeclaredField("otpStorage");
        f.setAccessible(true);
        Map<String,String> otpMap = (Map<String,String>) f.get(service);
        otpMap.put("z@z.com", "123123");

        boolean ok = service.verifyOtp("z@z.com", "wrong");
        assertThat(ok).isFalse();
        assertThat(otpMap).containsKey("z@z.com");
    }

    @Test
    public void sendBookingEmail_sendsCorrectSimpleMail() {
        BookingMailRequest b = BookingMailRequest.builder()
                .bookingId("B1").name("Alice").email("a@x.com")
                .contact("555").flightNumber("F2")
                .bookingStatus("CONF").seatType("BUS")
                .noOfSeats(3).paymentStatus("OK").paymentId("P2")
                .build();

        ArgumentCaptor<SimpleMailMessage> cap = ArgumentCaptor.forClass(SimpleMailMessage.class);
        service.sendBookingEmail(b);

        verify(mailSender).send(cap.capture());
        SimpleMailMessage msg = cap.getValue();
        assertThat(msg.getTo()).containsExactly("a@x.com");
        assertThat(msg.getSubject()).contains("Booking Confirmation - B1");
        assertThat(msg.getText()).contains("Hello Alice,").contains("Seats: 3 (BUS)");
    }

    @Test
    public void sendBookingCancellationEmail_sendsCorrectSimpleMail() {
        ArgumentCaptor<SimpleMailMessage> cap = ArgumentCaptor.forClass(SimpleMailMessage.class);
        service.sendBookingCancellationEmail("c@x.com","B10");

        verify(mailSender).send(cap.capture());
        SimpleMailMessage m = cap.getValue();
        assertThat(m.getTo()).containsExactly("c@x.com");
        assertThat(m.getSubject()).contains("Booking Cancelled: B10");
        assertThat(m.getText()).contains("has been cancelled successfully");
    }

    @Test
    public void sendCheckinMail_sendsMailAndReturnsString() {
        CheckinMailRequestDTO dto = new CheckinMailRequestDTO(
                "Z1", 999L, "d@x.com", List.of("A1","A2")
        );
        ArgumentCaptor<SimpleMailMessage> cap = ArgumentCaptor.forClass(SimpleMailMessage.class);

        String ret = service.sendCheckinMail(dto);

        verify(mailSender).send(cap.capture());
        SimpleMailMessage m = cap.getValue();
        assertThat(m.getTo()).containsExactly("d@x.com");
        assertThat(m.getSubject()).contains("Check-in Confirmation - Booking ID: Z1");
        assertThat(m.getText()).contains("Check-in ID: 999").contains("Assigned Seats: A1, A2");
        assertThat(ret).isEqualTo("Check-in mail sent successfully.");
    }
}