// src/test/java/com/flight_search_service/service/impl/FlightServiceImplTest.java
package com.flight_search_service.service.impl;

import com.flight_search_service.dto.FlightRequestDto;
import com.flight_search_service.dto.SearchRequestDto;
import com.flight_search_service.external.BookingServiceClient;
import com.flight_search_service.mapper.FlightMapper;
import com.flight_search_service.model.FareDetails;
import com.flight_search_service.model.Flight;
import com.flight_search_service.model.SeatType;
import com.flight_search_service.repositories.FlightRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class FlightServiceImplTest {

    @Mock
    private FlightRepository repo;

    @Mock
    private BookingServiceClient bookingClient;

    @Mock
    private FlightMapper mapper;

    @InjectMocks
    private FlightServiceImpl service;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void addFlight_whenNotExists_savesAndReturns() {
        // setup DTO
        FlightRequestDto dto = new FlightRequestDto();
        dto.setSource("BLR");
        dto.setDestination("DEL");
        dto.setDepartureDate(LocalDate.now().plusDays(1));
        dto.setDepartureTime(LocalTime.of(9, 0));
        dto.setAirline("IndiGo");

        // mapper and repo stubbing
        Flight entity = Flight.builder().flightNumber("BD_…_0900").build();
        when(mapper.toEntity(dto)).thenReturn(entity);
        when(repo.findByFlightNumber(entity.getFlightNumber())).thenReturn(Optional.empty());
        when(repo.save(entity)).thenReturn(entity);

        // act
        Optional<Flight> out = service.addFlight(dto);

        // assert
        assertThat(out).contains(entity);
        verify(repo).save(entity);
    }

    @Test
    void addFlight_whenExists_returnsEmpty() {
        Flight f = Flight.builder().flightNumber("X").build();
        when(mapper.toEntity(any())).thenReturn(f);
        when(repo.findByFlightNumber("X")).thenReturn(Optional.of(f));

        assertThat(service.addFlight(new FlightRequestDto())).isEmpty();
        verify(repo, never()).save(any());
    }

    @Test
    void searchFlights_noResults_throwsOK() {
        SearchRequestDto req = SearchRequestDto.builder()
                .source("SRC").destination("DST")
                .date(LocalDate.now().plusDays(2)).build();

        when(repo.findBySourceIgnoreCaseAndDestinationIgnoreCaseAndDepartureDate(
                req.getSource(), req.getDestination(), req.getDate()))
                .thenReturn(List.of());

        assertThatThrownBy(() -> service.searchFlights(req))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("200")
                .hasMessageContaining("No flights found");
    }

    @Test
    void getAllFlights_empty_throwsOK() {
        when(repo.findAll()).thenReturn(List.of());

        assertThatThrownBy(service::getAllFlights)
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("200");
    }

    @Test
    void getFare_missingFlight_throws404() {
        when(repo.findById("NF")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.getFareBySeatType("NF", SeatType.ECONOMY_CLASS))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("404");
    }

    @Test
    void getFare_missingSeat_throws400() {
        FareDetails fd = new FareDetails();
        fd.setPriceDetails(Map.of());
        when(repo.findById("F2")).thenReturn(Optional.of(
                Flight.builder().flightNumber("F2").fareDetails(fd).build()
        ));

        assertThatThrownBy(() -> service.getFareBySeatType("F2", SeatType.FIRST_CLASS))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("400");
    }

    @Test
    void increaseSeatsBooked_overbook_throws409() {
        FareDetails fd = new FareDetails();
        fd.setSeatsBooked(Map.of(SeatType.ECONOMY_CLASS, 200));
        when(repo.findById("F3")).thenReturn(Optional.of(
                Flight.builder().flightNumber("F3").fareDetails(fd).build()
        ));

        assertThatThrownBy(() -> service.increaseSeatsBooked("F3", SeatType.ECONOMY_CLASS, 1))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("409");
    }

    @Test
    void decreaseSeatsBooked_negativeAllowed() {
        Map<SeatType,Integer> booked = new HashMap<>();
        booked.put(SeatType.FIRST_CLASS, 1);
        FareDetails fd = new FareDetails();
        fd.setSeatsBooked(booked);

        Flight f = Flight.builder().flightNumber("F9").fareDetails(fd).build();
        when(repo.findById("F9")).thenReturn(Optional.of(f));
        when(repo.save(f)).thenReturn(f);

        String msg = service.decreaseSeatsBooked("F9", SeatType.FIRST_CLASS, 2);

        assertThat(msg).contains("Successfully cancelled 2 seats");
        assertThat(f.getFareDetails().getSeatsBooked().get(SeatType.FIRST_CLASS))
                .isEqualTo(-1);
    }

    @Test
    void deleteFlight_notFound_throws404() {
        when(repo.findByFlightNumber("X")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.deleteFlightByFlightNumber("X"))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("404");
    }

    @Test
    void deleteFlight_success_callsClientAndRepo() {
        // given an existing flight
        Flight f = Flight.builder().flightNumber("X").build();
        when(repo.findByFlightNumber("X")).thenReturn(Optional.of(f));

        // stub Feign client (returns a String)
        when(bookingClient.deleteBookingsByFlightNumber("X")).thenReturn("OK");

        // stub void repository delete
        doNothing().when(repo).deleteByFlightNumber("X");

        // when
        String resp = service.deleteFlightByFlightNumber("X");

        // then
        assertThat(resp).isEqualTo("Flight deleted successfully.");
        verify(bookingClient).deleteBookingsByFlightNumber("X");
        verify(repo).deleteByFlightNumber("X");
    }
}