package com.flight_search_service.controller;

import com.flight_search_service.dto.FlightRequestDto;
import com.flight_search_service.dto.FlightResponseDto;
import com.flight_search_service.dto.SearchRequestDto;
import com.flight_search_service.model.SeatType;
import com.flight_search_service.service.FlightService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class FlightControllerTest {

    @Mock private FlightService flightService;
    @InjectMocks private FlightController controller;

    @BeforeEach void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void addFlight_whenNew_returnsOkWithFlight() {
        var dto = new FlightRequestDto();
        dto.setAirline("XAir");
        dto.setSource("AAA");
        dto.setDestination("BBB");
        dto.setDepartureDate(LocalDate.now().plusDays(1));
        dto.setDepartureTime(LocalTime.of(10,  0));

        var saved = com.flight_search_service.model.Flight.builder()
                .flightNumber("AB_20250701_1000")
                .airline("XAir")
                .build();
        when(flightService.addFlight(dto)).thenReturn(Optional.of(saved));

        ResponseEntity<?> resp = controller.addFlight(dto);

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(resp.getBody()).isSameAs(saved);
    }

    @Test
    void addFlight_whenConflict_returns409() {
        when(flightService.addFlight(any()))
                .thenReturn(Optional.empty());

        FlightRequestDto dto = new FlightRequestDto();
        ResponseEntity<?> resp = controller.addFlight(dto);

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(resp.getBody())
                .isEqualTo("Flight is already registered");
    }

    @Test
    void getAllFlights_whenEmpty_throwsOK() {
        when(flightService.getAllFlights())
                .thenThrow(new ResponseStatusException(HttpStatus.OK, "No flights"));

        assertThatThrownBy(() -> controller.getAllFlights())
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("200")
                .hasMessageContaining("No flights");
    }

    @Test
    void searchFlights_whenNotFound_bubbles404() {
        var req = SearchRequestDto.builder()
                .source("A").destination("B")
                .date(LocalDate.now().plusDays(1))
                .build();

        when(flightService.searchFlights(req))
                .thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "No such route"));

        assertThatThrownBy(() -> controller.searchFlights(req))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("404")
                .hasMessageContaining("No such route");
    }

    @Test
    void getFare_delegatesToService() {
        when(flightService.getFareBySeatType("F1", SeatType.BUSINESS_CLASS))
                .thenReturn(1234.0);

        ResponseEntity<Double> resp = controller.getFare("F1", SeatType.BUSINESS_CLASS);
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(resp.getBody()).isEqualTo(1234.0);
    }

    // …and so on for other controller methods…
}