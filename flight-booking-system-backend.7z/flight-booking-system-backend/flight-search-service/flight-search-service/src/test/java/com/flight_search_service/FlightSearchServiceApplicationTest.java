// src/test/java/com/flight_search_service/FlightSearchServiceApplicationTest.java
package com.flight_search_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightSearchServiceApplicationTest {

    @Test
    void contextLoads() {
    }
}