package com.auth_service.services;

import com.auth_service.config.SecurityConfig;
import com.auth_service.dto.LoginRequest;
import com.auth_service.dto.LoginResponse;
import com.auth_service.dto.ResetPasswordRequest;
import com.auth_service.external.MailClient;
import com.auth_service.model.AppUser;
import com.auth_service.model.Role;
import com.auth_service.repositories.AppUserRepository;
import com.auth_service.security.JwtHelper;
import org.springframework.security.core.Authentication;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AuthServiceTest {

    @Mock private AuthenticationManager authenticationManager;
    @Mock private AppUserRepository userRepository;
    @Mock private JwtHelper jwtHelper;
    @Mock private SecurityConfig securityConfig;
    @Mock private MailClient mailClient;
    @Mock private PasswordEncoder passwordEncoder;

    @InjectMocks private AuthService authService;

    @BeforeEach
    void setup() {
        when(securityConfig.passwordEncoder()).thenReturn(passwordEncoder);
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");

        Authentication auth = mock(Authentication.class);
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(auth);
    }

    @Test
    void loginShouldReturnToken() {
        LoginRequest request = new LoginRequest();
        request.setUsername("john");
        request.setPassword("Pass@123");

        AppUser user = new AppUser();
        user.setUsername("john");
        user.setPassword("encodedPassword");
        user.setRole(Role.USER);

        when(userRepository.findByUsername("john")).thenReturn(Optional.of(user));
        when(jwtHelper.generateToken("john", Role.USER)).thenReturn("jwt-token");

        LoginResponse result = authService.login(request, "USER");

        assertEquals("jwt-token", result.getToken());
        assertEquals("john", result.getUsername());
    }

    // Additional tests like register, verifyOtp, forgotPassword, resetPassword, deleteRole, etc.
}