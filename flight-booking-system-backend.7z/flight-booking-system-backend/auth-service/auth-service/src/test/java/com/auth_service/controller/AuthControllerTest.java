package com.auth_service.controller;

import com.auth_service.dto.LoginRequest;
import com.auth_service.dto.LoginResponse;
import com.auth_service.model.AppUser;
import com.auth_service.services.AuthService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthController.class)
public class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private AuthService authService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void loginShouldReturnTokenOnSuccess() throws Exception {
        LoginRequest request = new LoginRequest();
        request.setUsername("john");
        request.setPassword("Pass@123");

        LoginResponse response = new LoginResponse("john", "jwt-token");

        when(authService.login(any(), eq("USER"))).thenReturn(response);

        mockMvc.perform(post("/api/auth/login/USER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("jwt-token"))
                .andExpect(jsonPath("$.username").value("john"));
    }

    @Test
    void registerShouldReturnConfirmationMessage() throws Exception {
        AppUser user = new AppUser();
        user.setUsername("john_doe");
        user.setPassword("Pass@1234");
        user.setEmail("john@example.com");

        when(authService.register(any(), eq("USER")))
                .thenReturn(ResponseEntity.ok("OTP sent"));

        mockMvc.perform(post("/api/auth/register/USER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(content().string("OTP sent"));
    }

    @Test
    void verifyOtpShouldSucceed() throws Exception {
        AppUser user = new AppUser();
        user.setUsername("john_doe");
        user.setPassword("Pass@1234");
        user.setEmail("john@example.com");

        when(authService.verifyOtpAndRegister(any(), eq("123456"), eq("USER")))
                .thenReturn(ResponseEntity.ok("User registered successfully"));

        mockMvc.perform(post("/api/auth/verify-otp/USER?otp=123456")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(content().string("User registered successfully"));
    }

    @Test
    void resetPasswordShouldSendOtp() throws Exception {
        when(authService.forgotPassword("john@example.com", "USER"))
                .thenReturn(ResponseEntity.ok("OTP sent"));

        mockMvc.perform(post("/api/auth/reset-password/USER")
                        .param("email", "john@example.com"))
                .andExpect(status().isOk())
                .andExpect(content().string("OTP sent"));
    }

    @Test
    void validateTokenShouldReturnValidMessage() throws Exception {
        doNothing().when(authService).validateToken("abc.def.ghi");

        mockMvc.perform(get("/api/auth/validate")
                        .param("token", "abc.def.ghi"))
                .andExpect(status().isOk())
                .andExpect(content().string("Token is valid"));
    }

    @Test
    void deleteUserShouldReturnSuccessMessage() throws Exception {
        LoginRequest request = new LoginRequest();
        request.setUsername("john");
        request.setPassword("Pass@123");

        doNothing().when(authService).deleteRole(any(), eq("USER"));

        mockMvc.perform(delete("/api/auth/delete/USER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(content().string("USER deleted successfully."));
    }
}