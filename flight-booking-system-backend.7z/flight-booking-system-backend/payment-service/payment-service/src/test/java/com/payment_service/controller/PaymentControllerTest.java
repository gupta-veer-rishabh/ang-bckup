// src/test/java/com/payment_service/controller/PaymentControllerTest.java
package com.payment_service.controller;

import com.payment_service.dto.PaymentStatusResponse;
import com.payment_service.service.PaymentService;
import com.razorpay.Order;
import com.razorpay.RazorpayException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class PaymentControllerTest {

    @Mock
    private PaymentService paymentService;

    @InjectMocks
    private PaymentController controller;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void createOrder_happyPath() throws Exception {
        // arrange: mock an Order
        Order order = mock(Order.class);

        // build a JSONObject subclass that overrides toMap()
        JSONObject fakeJson = new JSONObject() {
            public Map<String, Object> toMap() {
                return Map.of(
                        "id", "ord123",
                        "amount", 5000,
                        "currency", "INR"
                );
            }
        };

        when(order.get("id")).thenReturn("ord123");
        when(order.get("amount")).thenReturn(5000);
        when(order.get("currency")).thenReturn("INR");
        when(order.toJson()).thenReturn(fakeJson);

        when(paymentService.createOrder(50.00, "INR", "rcpt1")).thenReturn(order);

        // act
        ResponseEntity<Map<String,Object>> resp =
                controller.createPaymentOrder(50.00, "INR", "rcpt1");

        // assert
        assertThat(resp.getStatusCodeValue()).isEqualTo(200);
        Map<String,Object> body = resp.getBody();
        assertThat(body)
                .containsEntry("id", "ord123")
                .containsEntry("amount", 5000)
                .containsEntry("currency", "INR")
                .containsKey("payment_url");

        String url = (String) body.get("payment_url");
        assertThat(url).contains("orderId=ord123")
                .contains("amount=5000")
                .contains("currency=INR");
    }

    @Test
    public void createOrder_serviceThrows_wrapped() {
        when(paymentService.createOrder(anyDouble(), anyString(), anyString()))
                .thenThrow(new RuntimeException("boom"));

        assertThatThrownBy(() ->
                controller.createPaymentOrder(10,"USD","r1"))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("boom");
    }

    @Test
    public void verifyPayment_paid() throws RazorpayException {
        when(paymentService.isPaymentCaptured("ord123")).thenReturn("pay789");

        ResponseEntity<?> resp = controller.verifyPaymentStatus("ord123");
        assertThat(resp.getStatusCodeValue()).isEqualTo(200);

        PaymentStatusResponse status = (PaymentStatusResponse) resp.getBody();
        assertThat(status.getOrderId()).isEqualTo("ord123");
        assertThat(status.getPaymentId()).isEqualTo("pay789");
        assertThat(status.getStatus()).isEqualTo("paid");
    }

    @Test
    public void verifyPayment_pending() throws RazorpayException {
        when(paymentService.isPaymentCaptured("ord123")).thenReturn(null);

        var resp = controller.verifyPaymentStatus("ord123");
        var body = (PaymentStatusResponse) resp.getBody();
        assertThat(body.getStatus()).isEqualTo("pending");
    }

    @Test
    public void verifyPayment_exception() throws RazorpayException {
        when(paymentService.isPaymentCaptured("ordX"))
                .thenThrow(new RazorpayException("not found"));

        ResponseEntity<?> resp = controller.verifyPaymentStatus("ordX");
        assertThat(resp.getStatusCodeValue()).isEqualTo(400);
        assertThat(resp.getBody()).isEqualTo("not found");
    }

    @Test
    public void refundPayment_success() throws Exception {
        doReturn(null).when(paymentService).refundPayment("pay1");

        var resp = controller.refundPayment("pay1");
        assertThat(resp.getStatusCodeValue()).isEqualTo(200);
        assertThat(resp.getBody()).isEqualTo("Refund successfully");
    }

    @Test
    public void refundPayment_failure() throws RazorpayException {
        doThrow(new RazorpayException("bad"))
                .when(paymentService).refundPayment("payX");

        var resp = controller.refundPayment("payX");
        assertThat(resp.getStatusCodeValue()).isEqualTo(400);
        assertThat(resp.getBody()).isEqualTo("bad");
    }
}