// src/test/java/com/payment_service/service/PaymentServiceTest.java
package com.payment_service.service;

import com.payment_service.exceptions.PaymentServiceException;
import com.razorpay.Order;
import com.razorpay.Payment;
import com.razorpay.Refund;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

public class PaymentServiceTest {

    private RazorpayClient mockClient;
    private PaymentService service;

    @BeforeEach
    public void init() throws Exception {
        // instantiate service (creates real client internally)
        service = new PaymentService("dummyKey", "dummySecret");

        // replace its razorpayClient with a mock
        mockClient = mock(RazorpayClient.class);
        ReflectionTestUtils.setField(service, "razorpayClient", mockClient);
    }

    @Test
    public void createOrder_success() throws Exception {
        int expectedPaise = (int) (75.0 * 100);
        Order stubOrder = mock(Order.class);

        when(mockClient.orders.create(argThat(opts -> {
            // may throw JSONException
            JSONObject json = null;
            try {
                json = new JSONObject(opts.toString());
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
            try {
                return json.getInt("amount") == expectedPaise
                        && "USD".equals(json.getString("currency"))
                        && "r123".equals(json.getString("receipt"));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }))).thenReturn(stubOrder);

        Order out = service.createOrder(75.0, "USD", "r123");
        assertThat(out).isSameAs(stubOrder);
    }

    @Test
    public void createOrder_failure_throwsPaymentException() throws RazorpayException {
        when(mockClient.orders.create(any(JSONObject.class)))
                .thenThrow(new RuntimeException("rpc fail"));

        assertThatThrownBy(() -> service.createOrder(10, "INR", "r2"))
                .isInstanceOf(PaymentServiceException.class)
                .hasMessageContaining("Error creating Razorpay payment");
    }

    @Test
    public void isPaymentCaptured_found() throws RazorpayException {
        Payment p = mock(Payment.class);
        when(p.get("status")).thenReturn("captured");
        when(p.get("id")).thenReturn("pid1");
        when(mockClient.orders.fetchPayments("o1")).thenReturn(List.of(p));

        String result = service.isPaymentCaptured("o1");
        assertThat(result).isEqualTo("pid1");
    }

    @Test
    public void isPaymentCaptured_notFound() throws RazorpayException {
        Payment p = mock(Payment.class);
        when(p.get("status")).thenReturn("failed");
        when(mockClient.orders.fetchPayments("o2")).thenReturn(List.of(p));

        String result = service.isPaymentCaptured("o2");
        assertThat(result).isNull();
    }

    @Test
    public void refundPayment_alreadyCaptured() throws RazorpayException {
        Payment pay = mock(Payment.class);
        when(pay.get("status")).thenReturn("captured");
        when(mockClient.payments.fetch("pidA")).thenReturn(pay);

        Refund ref = mock(Refund.class);
        when(mockClient.refunds.create(any(JSONObject.class))).thenReturn(ref);

        Refund out = service.refundPayment("pidA");
        assertThat(out).isSameAs(ref);
        verify(mockClient.payments, never()).capture(anyString(), any(JSONObject.class));
    }

    @Test
    public void refundPayment_authorizedThenCaptureThenRefund() throws RazorpayException {
        Payment pay = mock(Payment.class);
        when(pay.get("status")).thenReturn("authorized");
        when(mockClient.payments.fetch("pidB")).thenReturn(pay);

        Payment captured = mock(Payment.class);
        when(mockClient.payments.capture(eq("pidB"), any(JSONObject.class))).thenReturn(captured);

        Refund ref = mock(Refund.class);
        when(mockClient.refunds.create(any(JSONObject.class))).thenReturn(ref);

        Refund out = service.refundPayment("pidB");
        assertThat(out).isSameAs(ref);
        verify(mockClient.payments).capture(eq("pidB"), any(JSONObject.class));
    }

    @Test
    public void refundPayment_invalidState_throws() throws RazorpayException {
        Payment pay = mock(Payment.class);
        when(pay.get("status")).thenReturn("failed");
        when(mockClient.payments.fetch("pidC")).thenReturn(pay);

        assertThatThrownBy(() -> service.refundPayment("pidC"))
                .isInstanceOf(PaymentServiceException.class)
                .hasMessageContaining("Payment is not captured. Current status: failed");
    }

    @Test
    public void refundPayment_fetchThrows_wrapped() throws RazorpayException {
        when(mockClient.payments.fetch("pidX"))
                .thenThrow(new RazorpayException("nope"));

        assertThatThrownBy(() -> service.refundPayment("pidX"))
                .isInstanceOf(RazorpayException.class)
                .hasMessageContaining("nope");
    }
}